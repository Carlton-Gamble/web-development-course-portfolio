/*

	IT 1430 - Web Page Development
	Fall 2019
	Exam 3 Part 2

	Exam 3 JavaScript 
	Author: Carlton Gamble
	Date:    4/24/2024

	Filename: lastName_exam3.js

*/

function mouse(inputParameter){
	alert(inputParameter);
}